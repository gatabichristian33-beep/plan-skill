# `/plan` — Skill de brainstorming pour AI Blueprint

Ce skill ajoute une étape manquante au workflow [ai-blueprint](https://github.com/bradtraversy/ai-blueprint) :
une **vraie session de brainstorming guidée** pour produire `project-plan.md`
et `build-plan.md` (à la racine du projet) avant même de lancer `/onboard` ou
`/overview`. Tu les déplaces ensuite toi-même dans `blueprint/`.

## Installation

### Dans un projet qui a déjà le Blueprint installé

Copie simplement le(s) dossier(s) correspondant à ton outil dans la racine de ton
projet, à côté des skills existants (`onboard`, `feature`, `overview`, etc.) :

```
ton-projet/
├── .claude/skills/plan/SKILL.md   ← copie ce dossier ici (Claude Code)
├── .agents/skills/plan/SKILL.md   ← copie ce dossier ici (Codex)
└── blueprint/
```

- Si tu utilises uniquement Claude Code : copie seulement `.claude/skills/plan/`.
- Si tu utilises uniquement Codex : copie seulement `.agents/skills/plan/`.
- Si tu switches entre les deux : garde les deux copies (elles sont alignées,
  comme le fait le Blueprint lui-même pour tous ses autres skills).

### Avant d'installer le Blueprint (tout premier projet)

Tu peux utiliser ce skill même **avant** d'installer le Blueprint officiel :
place le dossier `.claude/skills/plan/` (ou `.agents/skills/plan/`) à la racine
d'un dossier vide, ouvre Claude Code (ou Codex) dedans, et lance `/plan`
(ou `$plan`). Une fois les deux fichiers générés à la racine, tu scaffold ton
app, tu installes le Blueprint (`npx github:bradtraversy/ai-blueprint#npx`), tu
déplaces `project-plan.md` et `build-plan.md` dans `blueprint/`, puis tu
enchaînes avec `/onboard` → `/overview` → boucle `/feature`.

### Avec un autre outil / dans un chat classique (ChatGPT, Claude.ai, etc.)

Le fichier `SKILL.md` est aussi un excellent **system prompt / rôle** autonome.
Colle simplement son contenu (à partir de `# /plan — Guided Project
Brainstorming`) en début de conversation avec n'importe quelle IA — elle n'a pas
besoin du mécanisme de skills pour suivre les instructions.

## Utilisation

Une fois installé, lance simplement :

```
/plan
```

(ou `$plan` sous Codex, ou "lance une session de planning" en langage naturel).

L'IA va t'interviewer en 8 phases (cadrage, problème, utilisateurs,
fonctionnalités, données, stack technique, monétisation, UI/UX), refuser
d'avancer si tes réponses restent vagues, puis générer deux fichiers
**à la racine du projet** : `project-plan.md` et `build-plan.md` — jamais de
code, jamais de scaffolding.

Une fois générés, déplace-les toi-même vers `blueprint/project-plan.md` et
`blueprint/build-plan.md` (après avoir installé le Blueprint si ce n'est pas
déjà fait), puis lance `/overview`.

## Pourquoi un skill séparé plutôt qu'intégré à `/onboard`

`/onboard` suppose que les plans existent déjà (même sous forme de notes
brutes) — son rôle est de détecter la stack et calibrer les fichiers du
Blueprint. `/plan` s'exécute *avant*, quand il n'y a encore que l'idée dans la
tête de l'utilisateur. Les garder séparés respecte le principe du Blueprint :
chaque skill fait une seule chose, avec une porte de revue humaine entre les
étapes.

## Fichiers inclus

```
.
├── .claude/skills/plan/SKILL.md   (Claude Code)
├── .agents/skills/plan/SKILL.md   (Codex)
└── README.md                      (ce fichier)
```
