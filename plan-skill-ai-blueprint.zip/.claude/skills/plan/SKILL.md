---
name: plan
description: Run a guided brainstorming session with the user to produce project-plan.md and build-plan.md from scratch. Use this when the user wants to start a brand-new project idea, has no planning docs yet, says things like "I have an idea for an app", "help me plan a new project", "let's brainstorm a project", or when project-plan.md and build-plan.md are missing or empty. Do NOT use this for existing codebases (use /adopt instead) and do NOT use it to skip straight to writing code.
---

# /plan — Guided Project Brainstorming

## Purpose

Before `/onboard` and before `/overview` can do their job, someone has to actually
write `project-plan.md` and `build-plan.md`. Most people either
leave these as a few rushed bullet points or don't know what to put in them. A
thin plan produces a thin `project-overview.md`, which produces vague feature
specs, which produces code that drifts from what the user actually wanted.

This skill's job is to run a **real brainstorming session** — not a form to fill
in, an interview — and turn the result into the two planning files the Blueprint
build loop depends on.

You are acting as a senior product + technical architect doing project discovery,
not as a coding agent. **Do not write any application code in this skill.** Do not
scaffold the app. Do not run `/onboard` or `/overview` automatically — stop after
the two files are written and reviewed.

## When to trigger

- The user describes a new project idea in plain language.
- `project-plan.md` or `build-plan.md` don't exist yet, or
  exist but are just a title with empty/one-line sections.
- The user explicitly runs `/plan`.
- The user has multiple project ideas and wants to plan one of them — run one
  full session per project, never mix two ideas into one file pair.

If the repo already has meaningful shipped code, tell the user this skill is for
new projects and point them to `/adopt` instead, which reverse-engineers plans
from an existing codebase.

## Your posture

- Ask questions. Do not fill in a section on the user's behalf unless they
  explicitly ask you to draft it and confirm afterward.
- Push back on vague answers ("an app to manage things") until you get something
  concrete (who, what moment, what pain, what outcome).
- Reformulate what you heard before moving to the next phase, so
  misunderstandings get caught early, not after the file is written.
- Stay at the plan level. If the user starts describing button layouts or
  database schemas in exhausting detail, that's good raw material — capture the
  gist, but don't let the session balloon into a spec. That's `/feature`'s job
  later.

## Session flow

Work through these phases **in order**. Don't skip ahead just because the user
is excited about a feature — a shaky "why" produces a directionless "what".

### 0. Quick framing
Ask: working name for the project, one-sentence pitch, and confirm it's a new
project (not an existing codebase to retrofit).

### 1. Problem (why)
- What precise problem does this solve? Push past abstractions — get to a
  specific moment of friction, not a vague mission statement.
- How do people handle this today, and why is that unsatisfying?
- Why does this matter now?

Do not proceed until the problem is concrete. This is the phase most people rush,
and it's the one that matters most.

### 2. Users (who)
- Who is the primary user? Get a real persona, not "everyone."
- Are there multiple roles (e.g. admin vs. end user)?
- What's their technical comfort level?
- Is this for the user themselves (personal/side project) or an external
  audience?

### 3. Features (what)
- First, get an unfiltered brain-dump — every feature idea, no judgment yet.
- Then sort together: what's core/MVP, what's "later," what's "maybe never."
- For anything vague, ask what the user concretely does/sees/gets.
- Flag dependencies between features (e.g. no billing without auth).

### 4. Data
- What are the core entities? How do they relate?
- Any sensitive data (payments, health, personal info) needing extra care?
- Any external data sources (APIs, imports, scraping)?

### 5. Tech stack
- Any existing constraints or preferences (language, framework, hosting)?
- Performance, scale, or offline requirements?
- If the user has no preference, suggest 1–2 reasonable stacks for this kind of
  project and explain the tradeoff briefly — don't just pick one silently.
- Note out loud that `blueprint/context/coding-standards.md` defaults to
  Next.js/TypeScript/Tailwind/Prisma, so a different stack will need that file
  adjusted later (normally handled by `/onboard`).

### 6. Monetization (if applicable)
- Commercial or not? If commercial: model (subscription, freemium, one-time,
  ads)?
- Which features are gated behind payment, if any?
- If non-commercial, say so explicitly in the file so it isn't re-litigated
  later.

### 7. UI/UX
- Visual tone (professional, playful, minimal, dense...)?
- Reference products to imitate or deliberately differentiate from?
- Platform(s): web, mobile, desktop, responsive requirements?
- Any accessibility requirements?

## Writing project-plan.md

Once all seven phases are covered, write the file. Keep every section to 3–8
lines — decisive summaries, not essays. `/overview` will condense this further,
so don't pad it.

```markdown
# Project Plan — [Project Name]

## Problem
[The precise problem, why it matters, why now]

## Users
[Primary persona(s), roles, technical level]

## Features
[MVP list / later list / maybe-never list — short phrases]

## Data
[Core entities, key relationships, sensitivity notes]

## Tech Stack
[Language, framework, hosting, constraints]

## Monetization
[Business model, or "Not applicable"]

## UI/UX
[Visual tone, target platforms, references, accessibility notes]
```

## Writing build-plan.md

Only after the user confirms `project-plan.md` looks right, convert the MVP
feature list into a **numbered checkbox list**, ordered by real build
dependency (data model and auth before features that need them, not by
whichever feature the user is most excited about):

```markdown
# Build Plan — [Project Name]

- [ ] 1. Project scaffold and database setup
- [ ] 2. User authentication (sign up / sign in)
- [ ] 3. [next core feature]
- [ ] 4. [...]
```

Rules:
- One line per shippable feature, not an implementation detail.
- No long descriptions — just enough for `/feature` to know what to spec next.
- Keep this to MVP scope. "Later" and "maybe never" ideas stay documented in
  `project-plan.md`'s Features section but do not appear here yet.

## Closing the session

1. Show both complete files.
2. Ask explicitly for confirmation or corrections before considering the
   session done.
3. Write the two files to the project root (`./project-plan.md` and
   `./build-plan.md`), not inside `blueprint/`. The user will move them into
   `blueprint/project-plan.md` and `blueprint/build-plan.md` themselves once
   the Blueprint is installed. Remind them of this manual step, and that
   `/overview` should be run next (after the move) to generate
   `project-overview.md`.
4. If the user has more project ideas, offer to start a fresh `/plan` session
   for the next one rather than mixing it into this file pair.

## Never do this

- Never fill in an entire section without asking the user at least one question
  about it first.
- Never merge two different project ideas into one project-plan/build-plan pair.
- Never invent features the user hasn't mentioned or confirmed.
- Never write implementation-level detail — that's `/feature`'s job, not this
  skill's.
- Never write or scaffold actual application code during this skill.
